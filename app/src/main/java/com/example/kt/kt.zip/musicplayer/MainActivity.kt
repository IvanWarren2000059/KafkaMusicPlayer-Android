package com.example.musicplayer

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import android.graphics.drawable.AnimatedVectorDrawable


class MainActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout
    private lateinit var nowPlaying: TextView
    private lateinit var nowPlayingArtist: TextView
    private lateinit var playPauseBtn: ImageButton
    private lateinit var prevBtn: ImageButton
    private lateinit var nextBtn: ImageButton
    private lateinit var shuffleBtn: ImageButton
    private lateinit var seekBar: SeekBar
    private lateinit var fabAddPlaylist: FloatingActionButton
    
    private lateinit var kafkaIdle: ImageView
    private lateinit var kafkaPlaying: ImageView
    private lateinit var spiderWebBg: ImageView
    
    private var songList: List<Song> = emptyList()
    private var isShuffled = false
    private var isPlaying = false
    private var currentSong: Song? = null
    
    // Pulsating animation variables
    private var idlePulseAnimator: ValueAnimator? = null
    private var playingPulseAnimator: ValueAnimator? = null
    private var spiderWebPulseAnimator: ValueAnimator? = null
    
    private val seekBarHandler = Handler(Looper.getMainLooper())
    private var isUserSeeking = false

    companion object {
        private const val REQUEST_PERMISSION = 101
        const val DELETE_REQUEST_CODE = 1001
        private const val PREFS_NAME = "app_prefs"
        private const val KEY_BATTERY_PROMPT_SHOWN = "battery_prompt_shown"
        
        const val ACTION_UPDATE_UI = "UPDATE_UI"
        const val ACTION_UPDATE_PROGRESS = "UPDATE_PROGRESS"
        const val EXTRA_SONG_TITLE = "SONG_TITLE"
        const val EXTRA_SONG_ARTIST = "SONG_ARTIST"
        const val EXTRA_IS_PLAYING = "IS_PLAYING"
        const val EXTRA_CURRENT_POSITION = "CURRENT_POSITION"
        const val EXTRA_DURATION = "DURATION"
        
        private const val KAFKA_ANIM_DURATION = 300L
        
        // Pulsating animation constants
        private const val PULSE_DURATION = 2000L
        private const val PULSE_SCALE_MIN = 0.95f
        private const val PULSE_SCALE_MAX = 1.05f
        
        // Spider web pulsating
        private const val SPIDER_PULSE_DURATION = 3000L
        private const val SPIDER_SCALE_MIN = 1.0f
        private const val SPIDER_SCALE_MAX = 1.15f
    }

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_UPDATE_UI -> {
                    val title = intent.getStringExtra(EXTRA_SONG_TITLE)
                    val artist = intent.getStringExtra(EXTRA_SONG_ARTIST)
                    isPlaying = intent.getBooleanExtra(EXTRA_IS_PLAYING, false)
                    
                    updateNowPlaying(title, artist)
                    updatePlayPauseButton()
                    updateKafkaAnimation(isPlaying)
                    updateSpiderWebAnimation(isPlaying)
                }
                ACTION_UPDATE_PROGRESS -> {
                    val position = intent.getIntExtra(EXTRA_CURRENT_POSITION, 0)
                    val duration = intent.getIntExtra(EXTRA_DURATION, 0)
                    
                    if (!isUserSeeking && duration > 0) {
                        seekBar.max = duration
                        seekBar.progress = position
                    }
                }
            }
        }
    }

    private val seekBarRunnable = object : Runnable {
        override fun run() {
            val intent = Intent(this@MainActivity, PlayerService::class.java).apply {
                action = PlayerService.ACTION_REQUEST_PROGRESS
            }
            startService(intent)
            
            seekBarHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        requestBatteryOptimizationIfNeeded()
        setupListeners()

        // Start spider web animation
        (spiderWebBg.drawable as? AnimatedVectorDrawable)?.start()
        startSpiderWebPulse()
        
        val filter = IntentFilter().apply {
            addAction(ACTION_UPDATE_UI)
            addAction(ACTION_UPDATE_PROGRESS)
        }
        LocalBroadcastManager.getInstance(this).registerReceiver(updateReceiver, filter)

        if (hasStoragePermission()) {
            initApp()
            handleIncomingIntent(intent)
        } else {
            requestStoragePermission()
        }
        
        seekBarHandler.post(seekBarRunnable)
    }
    
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { handleIncomingIntent(it) }
    }
    
    private fun handleIncomingIntent(intent: Intent) {
        when (intent.action) {
            Intent.ACTION_VIEW -> {
                intent.data?.let { uri ->
                    playExternalAudioFile(uri)
                }
            }
        }
    }
    
    private fun playExternalAudioFile(uri: Uri) {
        try {
            val song = getSongFromUri(uri)
            
            if (song != null) {
                Toast.makeText(
                    this,
                    "Playing: ${song.title}",
                    Toast.LENGTH_SHORT
                ).show()
                
                playSong(song, isolateMode = true)
            } else {
                Toast.makeText(
                    this,
                    "Could not play this file",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "Error playing external file", e)
            Toast.makeText(
                this,
                "Error: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
    
    /**
     * Enhanced getSongFromUri with multiple fallback methods
     * Handles files from SD card, external storage, and various file managers
     */
    private fun getSongFromUri(uri: Uri): Song? {
        return try {
            // Method 1: Try MediaStore query first (works for files in MediaStore)
            val mediaStoreSong = getSongFromMediaStore(uri)
            if (mediaStoreSong != null) {
                Log.d("MainActivity", "Got song from MediaStore: ${mediaStoreSong.title}")
                return mediaStoreSong
            }
            
            // Method 2: Try MediaMetadataRetriever (works for any accessible file)
            val metadataSong = getSongFromMetadata(uri)
            if (metadataSong != null) {
                Log.d("MainActivity", "Got song from metadata: ${metadataSong.title}")
                return metadataSong
            }
            
            // Method 3: Fallback to filename
            val filenameSong = getSongFromFilename(uri)
            Log.d("MainActivity", "Got song from filename: ${filenameSong.title}")
            filenameSong
            
        } catch (e: Exception) {
            Log.e("MainActivity", "Error getting song from URI", e)
            // Last resort: use URI path as title
            val filename = uri.lastPathSegment ?: "Unknown"
            Song(filename, "Unknown Artist", uri)
        }
    }
    
    /**
     * Try to get song info from MediaStore
     */
    private fun getSongFromMediaStore(uri: Uri): Song? {
        return try {
            val projection = arrayOf(
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST
            )
            
            contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val titleIndex = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                    val artistIndex = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                    
                    val title = if (titleIndex >= 0) {
                        cursor.getString(titleIndex)?.takeIf { it.isNotEmpty() }
                    } else null
                    
                    val artist = if (artistIndex >= 0) {
                        cursor.getString(artistIndex)?.takeIf { it.isNotEmpty() }
                    } else null
                    
                    // Only return if we got actual metadata (not just "Unknown Title")
                    if (title != null && title != "Unknown Title") {
                        Song(title, artist ?: "Unknown Artist", uri)
                    } else {
                        null
                    }
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "MediaStore query failed", e)
            null
        }
    }
    
    /**
     * Try to extract metadata using MediaMetadataRetriever
     * This works for files on SD card and external storage
     */
    private fun getSongFromMetadata(uri: Uri): Song? {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?.takeIf { it.isNotEmpty() && it != "Unknown Title" }
            
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?.takeIf { it.isNotEmpty() && it != "<unknown>" }
            
            retriever.release()
            
            // Only return if we got actual metadata
            if (title != null) {
                Song(title, artist ?: "Unknown Artist", uri)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "MediaMetadataRetriever failed", e)
            null
        }
    }
    
    /**
     * Extract song info from filename as last resort
     */
    private fun getSongFromFilename(uri: Uri): Song {
        // Try different methods to get filename
        val filename = when {
            // Try lastPathSegment first
            uri.lastPathSegment != null -> uri.lastPathSegment!!
            // Try path
            uri.path != null -> uri.path!!.substringAfterLast('/')
            // Last resort
            else -> "Unknown"
        }
        
        // Clean up the filename
        val cleanName = filename
            .replace(Regex("\\.[^.]+$"), "") // Remove extension
            .replace(Regex("[_-]+"), " ") // Replace underscores/dashes with spaces
            .trim()
        
        return Song(
            title = cleanName.ifEmpty { "Unknown Title" },
            artist = "Unknown Artist",
            uri = uri
        )
    }

    private fun requestBatteryOptimizationIfNeeded() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val hasShownPrompt = prefs.getBoolean(KEY_BATTERY_PROMPT_SHOWN, false)
        
        if (hasShownPrompt) return
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            val packageName = packageName
            
            if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                AlertDialog.Builder(this, R.style.KafkaDialog)
                    .setTitle("Battery Optimization")
                    .setMessage("To keep Kafka's Music Player running smoothly in the background, please disable battery optimization.\n\nThis ensures uninterrupted playback and proper controls.")
                    .setPositiveButton("Open Settings") { _, _ ->
                        try {
                            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                data = Uri.parse("package:$packageName")
                            }
                            startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(
                                this,
                                "Could not open battery settings",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    .setNegativeButton("Maybe Later", null)
                    .setOnDismissListener {
                        prefs.edit().putBoolean(KEY_BATTERY_PROMPT_SHOWN, true).apply()
                    }
                    .show()
            }
        }
    }

    private fun initViews() {
        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)
        nowPlaying = findViewById(R.id.nowPlaying)
        nowPlayingArtist = findViewById(R.id.nowPlayingArtist)
        playPauseBtn = findViewById(R.id.playPauseBtn)
        prevBtn = findViewById(R.id.prevBtn)
        nextBtn = findViewById(R.id.nextBtn)
        shuffleBtn = findViewById(R.id.shuffleBtn)
        seekBar = findViewById(R.id.seekBar)
        fabAddPlaylist = findViewById(R.id.fabAddPlaylist)
        
        kafkaIdle = findViewById(R.id.kafkaIdle)
        kafkaPlaying = findViewById(R.id.kafkaPlaying)
        spiderWebBg = findViewById(R.id.kafkaSpiderWebBg)
        
        startIdlePulse()
    }

    private fun setupListeners() {
        playPauseBtn.setOnClickListener {
            val intent = Intent(this, PlayerService::class.java).apply {
                action = PlayerService.ACTION_PLAY_PAUSE
            }
            startService(intent)
        }

        prevBtn.setOnClickListener {
            val intent = Intent(this, PlayerService::class.java).apply {
                action = PlayerService.ACTION_PREV
            }
            startService(intent)
        }

        nextBtn.setOnClickListener {
            val intent = Intent(this, PlayerService::class.java).apply {
                action = PlayerService.ACTION_NEXT
            }
            startService(intent)
        }

        shuffleBtn.setOnClickListener {
            isShuffled = !isShuffled
            updateShuffleButton()
            
            val intent = Intent(this, PlayerService::class.java).apply {
                action = PlayerService.ACTION_SHUFFLE_TOGGLE
                putExtra(PlayerService.EXTRA_SHUFFLE_STATE, isShuffled)
            }
            startService(intent)
            
            Toast.makeText(
                this, 
                if (isShuffled) "🔀 Shuffle ON" else "▶️ Shuffle OFF",
                Toast.LENGTH_SHORT
            ).show()
        }
        
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // Do nothing during drag
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = true
            }
            
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isUserSeeking = false
                seekBar?.let {
                    val intent = Intent(this@MainActivity, PlayerService::class.java).apply {
                        action = PlayerService.ACTION_SEEK
                        putExtra(PlayerService.EXTRA_SEEK_POSITION, it.progress)
                    }
                    startService(intent)
                }
            }
        })
        
        fabAddPlaylist.setOnClickListener {
            val fragment = supportFragmentManager.findFragmentByTag("f1")
            if (fragment is PlaylistsFragment) {
                fragment.showCreatePlaylistDialog()
            }
        }
        
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                if (position == 1) {
                    fabAddPlaylist.show()
                } else {
                    fabAddPlaylist.hide()
                }
            }
        })
    }

    private fun hasStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_MEDIA_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        else
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestStoragePermission() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.READ_MEDIA_AUDIO
        else
            Manifest.permission.READ_EXTERNAL_STORAGE

        ActivityCompat.requestPermissions(this, arrayOf(permission), REQUEST_PERMISSION)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSION &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            initApp()
        } else {
            nowPlaying.text = "Storage permission required"
        }
    }
    
    // Handle delete permission callback
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        Log.d("MainActivity", "========================================")
        Log.d("MainActivity", "onActivityResult called")
        Log.d("MainActivity", "requestCode: $requestCode")
        Log.d("MainActivity", "resultCode: $resultCode")
        Log.d("MainActivity", "DELETE_REQUEST_CODE: $DELETE_REQUEST_CODE")
        Log.d("MainActivity", "RESULT_OK: ${Activity.RESULT_OK}")
        Log.d("MainActivity", "RESULT_CANCELED: ${Activity.RESULT_CANCELED}")
        Log.d("MainActivity", "========================================")
        
        if (requestCode == DELETE_REQUEST_CODE) {
            Log.d("MainActivity", "✅ Request code matches DELETE_REQUEST_CODE")
            
            if (resultCode == Activity.RESULT_OK) {
                Log.d("MainActivity", "✅ User approved deletion")
                
                // Get the URI that was pending deletion
                val deletedUri = SongAdapter.pendingDeletionUri
                
                if (deletedUri != null) {
                    Log.d("MainActivity", "📦 Pending deletion URI: $deletedUri")
                    
                    Toast.makeText(this, "🗑️ Song deleted successfully", Toast.LENGTH_SHORT).show()
                    
                    // Update the main song list
                    songList = songList.filter { it.uri.toString() != deletedUri }
                    Log.d("MainActivity", "✅ Song removed from main list. New count: ${songList.size}")
                    
                    // Broadcast deletion so all fragments/adapters can update
                    val intent = Intent(SongAdapter.ACTION_SONG_DELETED).apply {
                        putExtra(SongAdapter.EXTRA_DELETED_URI, deletedUri)
                    }
                    LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
                    Log.d("MainActivity", "📡 Broadcast sent to all adapters")
                    
                    // Also directly update all currently active fragments
                    updateFragmentsAfterDeletion(deletedUri)
                    
                    // Clear the pending deletion
                    SongAdapter.pendingDeletionUri = null
                } else {
                    Log.w("MainActivity", "⚠️ No pending deletion URI found")
                }
            } else {
                Log.d("MainActivity", "❌ User cancelled deletion (resultCode: $resultCode)")
                Toast.makeText(this, "Delete cancelled", Toast.LENGTH_SHORT).show()
                // Clear pending deletion on cancel
                SongAdapter.pendingDeletionUri = null
            }
        } else {
            Log.d("MainActivity", "❌ Request code does NOT match (got $requestCode, expected $DELETE_REQUEST_CODE)")
        }
    }
    
    /**
     * Directly update the current visible fragment after a song is deleted
     */
    private fun updateFragmentsAfterDeletion(deletedUri: String) {
        Log.d("MainActivity", "🔄 Updating current fragment after deletion")
        
        // ViewPager2 manages fragments internally, so we use a tag-based approach
        val currentFragment = supportFragmentManager.findFragmentByTag("f${viewPager.currentItem}")
        
        Log.d("MainActivity", "Current item: ${viewPager.currentItem}")
        Log.d("MainActivity", "Fragment tag: f${viewPager.currentItem}")
        Log.d("MainActivity", "Found fragment: ${currentFragment?.javaClass?.simpleName}")
        
        when (currentFragment) {
            is SongsFragment -> {
                Log.d("MainActivity", "📝 Updating SongsFragment")
                currentFragment.removeSongFromAdapter(deletedUri)
            }
            else -> {
                Log.d("MainActivity", "ℹ️ Not a SongsFragment, no update needed")
            }
        }
    }

    private fun initApp() {
        val serviceIntent = Intent(this, PlayerService::class.java)
        startService(serviceIntent)

        songList = scanSongs(this)
        
        val adapter = ViewPagerAdapter(this, songList)
        viewPager.adapter = adapter
        
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = when(position) {
                0 -> "All Songs"
                1 -> "Playlists"
                2 -> "Folders"
                else -> "Tab $position"
            }
        }.attach()
        
        fabAddPlaylist.hide()
    }

    fun playSong(song: Song, isolateMode: Boolean = false) {
        currentSong = song
        
        Log.d("MainActivity", "Playing: ${song.title}")
        
        val playIntent = Intent(this, PlayerService::class.java).apply {
            action = PlayerService.ACTION_PLAY
            putExtra(PlayerService.EXTRA_SONG_URI, song.uri.toString())
            putExtra(PlayerService.EXTRA_SONG_TITLE, song.title)
            putExtra(PlayerService.EXTRA_SONG_ARTIST, song.artist)
            putExtra(PlayerService.EXTRA_ISOLATE_MODE, isolateMode)
        }
        startService(playIntent)
        
        updateNowPlaying(song.title, song.artist)
        isPlaying = true
        updatePlayPauseButton()
        updateKafkaAnimation(true)
        updateSpiderWebAnimation(true)
    }
    
    private fun updateNowPlaying(title: String?, artist: String?) {
        nowPlaying.text = title ?: "Select a song..."
        nowPlayingArtist.text = artist ?: "Unknown Artist"
    }

    private fun updatePlayPauseButton() {
        playPauseBtn.setImageResource(
            if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun updateShuffleButton() {
        shuffleBtn.alpha = if (isShuffled) 1.0f else 0.5f
    }
    
    private fun updateKafkaAnimation(playing: Boolean) {
        if (playing) {
            animateKafkaToPlaying()
        } else {
            animateKafkaToIdle()
        }
    }
    
    private fun animateKafkaToPlaying() {
        kafkaIdle.animate()
            .alpha(0f)
            .setDuration(KAFKA_ANIM_DURATION)
            .withEndAction {
                kafkaIdle.visibility = View.GONE
                stopIdlePulse()
            }
            .start()
        
        kafkaPlaying.visibility = View.VISIBLE
        kafkaPlaying.animate()
            .alpha(1f)
            .setDuration(KAFKA_ANIM_DURATION)
            .withEndAction {
                startPlayingPulse()
            }
            .start()
    }
    
    private fun animateKafkaToIdle() {
        kafkaPlaying.animate()
            .alpha(0f)
            .setDuration(KAFKA_ANIM_DURATION)
            .withEndAction {
                kafkaPlaying.visibility = View.GONE
                stopPlayingPulse()
            }
            .start()
        
        kafkaIdle.visibility = View.VISIBLE
        kafkaIdle.animate()
            .alpha(1f)
            .setDuration(KAFKA_ANIM_DURATION)
            .withEndAction {
                startIdlePulse()
            }
            .start()
    }
    
    // ========== KAFKA PULSATING ANIMATIONS ==========
    
    private fun startIdlePulse() {
        stopIdlePulse()
        
        idlePulseAnimator = ValueAnimator.ofFloat(PULSE_SCALE_MIN, PULSE_SCALE_MAX).apply {
            duration = PULSE_DURATION
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            
            addUpdateListener { animation ->
                val scale = animation.animatedValue as Float
                kafkaIdle.scaleX = scale
                kafkaIdle.scaleY = scale
            }
            
            start()
        }
    }
    
    private fun stopIdlePulse() {
        idlePulseAnimator?.cancel()
        idlePulseAnimator = null
        kafkaIdle.scaleX = 1f
        kafkaIdle.scaleY = 1f
    }
    
    private fun startPlayingPulse() {
        stopPlayingPulse()
        
        playingPulseAnimator = ValueAnimator.ofFloat(PULSE_SCALE_MIN, PULSE_SCALE_MAX).apply {
            duration = PULSE_DURATION
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            
            addUpdateListener { animation ->
                val scale = animation.animatedValue as Float
                kafkaPlaying.scaleX = scale
                kafkaPlaying.scaleY = scale
            }
            
            start()
        }
    }
    
    private fun stopPlayingPulse() {
        playingPulseAnimator?.cancel()
        playingPulseAnimator = null
        kafkaPlaying.scaleX = 1f
        kafkaPlaying.scaleY = 1f
    }
    
    // ========== SPIDER WEB BACKGROUND ANIMATION ==========
    
    private fun updateSpiderWebAnimation(playing: Boolean) {
        if (playing) {
            startSpiderWebPulse()
        } else {
            stopSpiderWebPulse()
        }
    }
    
    private fun startSpiderWebPulse() {
        stopSpiderWebPulse()
        
        spiderWebPulseAnimator = ValueAnimator.ofFloat(SPIDER_SCALE_MIN, SPIDER_SCALE_MAX).apply {
            duration = SPIDER_PULSE_DURATION
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            
            addUpdateListener { animation ->
                val scale = animation.animatedValue as Float
                spiderWebBg.scaleX = scale
                spiderWebBg.scaleY = scale
            }
            
            start()
        }
    }
    
    private fun stopSpiderWebPulse() {
        spiderWebPulseAnimator?.cancel()
        spiderWebPulseAnimator = null
        spiderWebBg.scaleX = 1f
        spiderWebBg.scaleY = 1f
    }

    override fun onDestroy() {
        super.onDestroy()
        seekBarHandler.removeCallbacks(seekBarRunnable)
        LocalBroadcastManager.getInstance(this).unregisterReceiver(updateReceiver)
        stopIdlePulse()
        stopPlayingPulse()
        stopSpiderWebPulse()
    }
}